#include "janelagrafico.h"
#include "ui_janelagrafico.h"

janelagrafico::janelagrafico(Empresa& emp,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::janelagrafico),empgrafico{emp}
{
    ui->setupUi(this);
    auto pv = empgrafico.prodvendas();
    //ui->tableWidget->clear();
    int r=0;
    //Adicionando dados na tabela venda
    for(auto& p: pv){
        QString cliente{p.getCliente().c_str()};//recebe cliente da empresa
        QString prod{p.getNome().c_str()};//Nome do produto vendido
        QString vlr = QString::number(p.getValor());// cast feito para conseguir inserir o float como qtsring
        ui->tableWidget->insertRow(1);//cria uma nova linha e linhas seguintes inserem os dados
        ui->tableWidget->setItem(r,0,new QTableWidgetItem{cliente});
        ui->tableWidget->setItem(r,1,new QTableWidgetItem{prod} );
        ui->tableWidget->setItem(r,2,new QTableWidgetItem{vlr});
        r++;
    }
    //adcionando dados na tabela compra
    auto cp = empgrafico.compras();
    int r2 = 0;
    for(auto& c: cp){
        QString forn{c.getFornecedor().c_str()};//fornecedor da compra
        QString qtde = QString::number(c.getQtde());//quantidade comprada
        QString vlr = QString::number(c.getValor());// cast feito para conseguir inserir o float como qtsring
        ui->tableWidget_2->insertRow(1);//cria uma nova linha e linhas seguintes inserem os dados
        ui->tableWidget_2->setItem(r2,0,new QTableWidgetItem{forn});
        ui->tableWidget_2->setItem(r2,1,new QTableWidgetItem{vlr} );
        ui->tableWidget_2->setItem(r2,2,new QTableWidgetItem{qtde});
        r2++;
    }
    //Adicionar o lucro
    empgrafico.setLucro(pv,cp);
    QString lucro = QString::number(empgrafico.getLucro());
    ui->listWidget->addItem(lucro);
}
janelagrafico::~janelagrafico()
{
    delete ui;
}
//botao voltar
void janelagrafico::on_pushButton_clicked()
{
    hide();
    parentWidget()->show();//volta para main window
}
