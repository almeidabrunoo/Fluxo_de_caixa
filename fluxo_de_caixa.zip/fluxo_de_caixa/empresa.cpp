#include "empresa.h"

//construtor
Empresa::Empresa()
{

}
//funções para adicionar classes em seus vetores
void Empresa::adicionarProdutos(const Produto &um)
{
    meusprodutos.push_back(um);
}

void Empresa::adicionarVendas(Venda umaVenda)
{
    minhasvendas.push_back(umaVenda);
}
void Empresa::adicionarCompras(Compra umaCompra)
{
    minhascompras.push_back(umaCompra);
}
//retornar os vetores
std::vector<std::string> Empresa::produtos() const
{
    std::vector<std::string> ret;
    for(auto& prod: meusprodutos){
        ret.push_back(prod.getNome());
    }
    return ret;
}

std::vector<Produto> Empresa::prodvendas() const
{
    std::vector<Produto> ret;
    for(auto vend: meusprodutos){
        ret.push_back(vend);
    }
    return ret;
}
std::vector<Compra> Empresa::compras()const{
    std::vector<Compra> ret;
    for(auto cmp:minhascompras){
        ret.push_back(cmp);
    }
    return ret;
}

void Empresa::setLucro(std::vector<Produto> meusprodutos, std::vector<Compra> minhascompras){
    _lucro.setMeuLucro(meusprodutos, minhascompras);
}


float Empresa::getLucro(){
    return _lucro.getMeuLucro();
}
