#include "janelavenda.h"
#include "ui_janelavenda.h"
#include "venda.h"
#include "testes.h"
#include <QMessageBox>

janelavenda::janelavenda(Empresa& emp,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::janelavenda), empvenda{emp}
{
    ui->setupUi(this);
    auto osproduto = empvenda.produtos();
    for(auto prod:osproduto){
        ui->comboBox_3->addItem(QString{prod.c_str()});// adicionando produtos manualmente ao combobox
    }
}

janelavenda::~janelavenda()
{
    delete ui;
}


/*
 1= crédito || À vista
 2= débito || Parcelado
 3= boleto
 4= cheque
 5= transferência
 */
//Quando botao finalizar apertado
void janelavenda::on_pushButton_clicked()
{

    int tvalor, tqtde, tcliente, tdata, tmtdcdc; //variaveis para testagem

    QString selecproj = ui->comboBox_3->currentText();; //string para comparação do projeto selecionado.
    std::string nome = selecproj.toStdString();
    //int numproj = 0; //numero equivalente no construtor da classe.

    QString svalor = ui->lineEdit_2->text(); // valor em string
    int valor = svalor.toFloat(); //conversao para float    
    if(testevalor(valor) == 1){
        tvalor = 1;
        QMessageBox::critical(this,"Nao pode!", "O valor do produto inserido é inválido!",QMessageBox::Ok);
      }
      else
        tvalor = 0;

    QString sqtde = ui->lineEdit_3->text(); // qtde em string
    int qtde = sqtde.toInt(); //conversao para int
    if(testeqtde(qtde) == 1){
        tqtde = 1;
        QMessageBox::critical(this,"Nao pode!", "A quantidade do produto inserido é inválida!",QMessageBox::Ok);
    }
    else
        tqtde = 0;

    QString qcliente = ui->lineEdit_4->text(); //recebendo o cliente em qstring
    std::string cliente = qcliente.toStdString(); //conversao string normal
    if(testestrings(cliente) == 1){
        tcliente = 1;
        QMessageBox::critical(this,"Nao pode!", "O cliente do produto inserido é inválido!",QMessageBox::Ok);
    }
    else
        tcliente = 0;

    QString sdia = ui->lineEdit_5->text(); // dia em string
    int dia = sdia.toInt(); // conversao int

    QString smes = ui->lineEdit_6->text(); // mes em string
    int mes = smes.toInt(); // conversao para int

    QString sano = ui->lineEdit_7->text(); // ano em string
    int ano = sano.toInt(); //conversao para int
    if(testedata(dia, mes, ano) == 1){
        tdata = 1;
        QMessageBox::critical(this,"Nao pode!", "A data inserida da venda é inválida!",QMessageBox::Ok);
    }
    else
        tdata = 0;

    QString selecmtd = ui->comboBox->currentText(); //string para comparação do metodo selecionado.
    int nummtd = 0; //numero equivalente na funcao da classe.

    if(selecmtd == "Crédito")
        nummtd = 1;
    else if(selecmtd == "Débito")
        nummtd = 2;
    else if(selecmtd == "Boleto")
        nummtd = 3;
    else if(selecmtd == "Cheque")
        nummtd = 4;
    else if(selecmtd == "Transferência")
        nummtd = 5;
    //teste metodo nao necessario pois opçoes sao determinadas

    QString seleccond = ui->comboBox_2->currentText();  //string para comparação da condicao selecionada.
    int numcond;  // numero equivalente na funcao da classe

    if(seleccond == "À vista")
        numcond = 1;
    else numcond = 2;
    //teste condição nao necesssario pois opções sao determinadas

    if(testemtdcndc(nummtd, numcond) == 1){
        tmtdcdc = 1;
        QMessageBox::critical(this,"Nao pode!", "Só é possível parcelar se pagar com crédito!",QMessageBox::Ok);
    }
    else
        tmtdcdc = 0;

    int testes = tvalor + tqtde + tcliente + tdata + tmtdcdc;

    if((testes) == 0){
        QMessageBox::StandardButton resposta = QMessageBox::question
                (this, "Objeto a ser criado", "Deseja criar o objeto Venda?",QMessageBox::Yes|QMessageBox::No);
        if(resposta == QMessageBox::Yes){
            Produto p1; // criação de objeto para guardar as informaçoes
            p1.setNome(nome);
            p1.setValor(valor);
            p1.setQtde(qtde);
            p1.setCliente(cliente);
            p1.setDia(dia);
            p1.setMes(mes);
            p1.setAno(ano);
            p1.setMetodo(nummtd);
            p1.setCondicao(numcond);
            empvenda.adicionarProdutos(p1); // adicionando ao vetor contido em empresa iniciada em main window
            QMessageBox::information(this,"","Objeto Venda criado",QMessageBox::Ok);
        }
        else
            QMessageBox::information(this,"","Objeto Venda não foi criado",QMessageBox::Ok);
    }
    else
        QMessageBox::critical(this,"Erros existentes!", "Conserte os erros antes de poder criar o objeto Venda"
                                                                          ,QMessageBox::Ok);

}
//Botao voltar
void janelavenda::on_pushButton_2_clicked(){
    hide();
    parentWidget()->show(); //volta para main window

}
