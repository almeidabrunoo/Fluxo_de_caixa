#include <iostream>
#include "venda.h"

//construtores
Venda::Venda(int qtde, float valor, std::string cliente, int dia, int mes, int ano) :
    _qtde(qtde),_valor(valor), _cliente(cliente), _dia(dia), _mes(mes), _ano(ano)
{

}

Venda::Venda(){

}
//destrutor
Venda::~Venda(){}

//funções setters
void Venda::setQtde(int qtde){
    if (qtde <= 0 ){
        std::cout<<"Quantidade inválida. Insira novamente.";
        int nqtde;
        std::cin>>nqtde;
        setQtde(nqtde);
    }
    else _qtde = qtde;
}

void Venda::setValor(float valor){
    if(valor <= 0){
        std::cout<<"Valor inválido. Insira novamente.";
        float nvalor;
        std::cin>>nvalor;
        setValor(nvalor);
    }
    else _valor = valor;
}
void Venda::setDia(int dia){
    if(dia >= 1 && dia < 31){
        _dia = dia;
    }
    else {
        std::cout << "Dia inválido. Insira novamente." <<std::endl;
        int ndia;
        std::cin>>ndia;
        setDia(ndia);
    }
}
void Venda::setAno(int ano){
    if(ano >= 0){
        _ano = ano;
    }
    else {
        std::cout << "Ano inválido. Insira novamente." << std::endl;
        int nano;
        std::cin>>nano;
        setDia(nano);
    }
}
void Venda::setMes(int mes){
    if(mes >= 1 && mes < 13){
        _mes = mes;
    }
    else {
        std::cout << "Mês inválido. Insira novamente." << std::endl;
        int nmes;
        std::cin>>nmes;
        setDia(nmes);
    }
}
void Venda::setCliente(std::string cliente){
    if(cliente.size() <= 2){
       std::string ncliente;
       std::cout<< "Cliente inválido. Insira novamente";
       std::getline(std::cin,ncliente);
       setCliente(ncliente);
    }
    else _cliente = cliente;

}
void Venda::setMetodo(int metodo){
    _metodo.setMetodo(metodo);

}
void Venda::setCondicao(int condicao){
    _condicao.setCondicao(condicao);

}
//funções getters
int Venda::getQtde(){
    return _qtde;

}
float Venda::getValor(){
    return _valor;
}
int Venda::getDia(){
    return _dia;
}
int Venda::getMes(){
    return _mes;
}
int Venda::getAno(){
    return _ano;
}
void Venda::getData(){
    std::cout << "(" << getDia() << "/" << getMes() << "/" << getAno() << ")" <<std::endl;

}
std::string Venda::getCliente(){
    return _cliente;

}

std::string Venda::getMetodo(){
    return _metodo.getMetodo();

}
std::string Venda::getCondicao(){
    return _condicao.getCondicao();

}

