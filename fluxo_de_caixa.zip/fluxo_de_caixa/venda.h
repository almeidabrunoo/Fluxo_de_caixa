#ifndef VENDA_H
#define VENDA_H

#include <iostream>
#include <string>
#include "pagamento.h"

class Venda{
private:
    int _qtde;
    float _valor;
    std::string _cliente;
    int _dia;
    int _mes;
    int _ano;
    Pagamento _metodo;
    Pagamento _condicao;

public:
    ~Venda();
    Venda();
    Venda(int qtde, float valor, std::string cliente, int dia, int ano, int mes);
    void setQtde(int qtde);
    void setProduto(int nome);
    void setValor(float valor);
    void setDia(int dia);
    void setMes(int mes);
    void setAno(int ano);
    void setCliente(std::string cliente);
    int getQtde();
    float getValor();
    int getDia();
    int getMes();
    int getAno();
    void getData();
    std::string getCliente();
    void setMetodo(int metodo);
    void setCondicao(int condicao);
    std::string getMetodo();
    std::string getCondicao();


};

#endif
