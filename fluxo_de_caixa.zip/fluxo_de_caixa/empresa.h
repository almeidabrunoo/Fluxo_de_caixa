#ifndef EMPRESA_H
#define EMPRESA_H

#include "lucro.h"
#include <vector>
#include "produto.h"
#include "venda.h"
#include "compra.h"


class Empresa
{
private:
    Lucro _lucro; //mais associação
    std::vector<Produto> meusprodutos;
    std::vector<Venda> minhasvendas;
    std::vector<Compra> minhascompras;
public:
    Empresa();
    void adicionarProdutos(const Produto & um);
    void adicionarVendas(Venda umaVenda);
    void adicionarCompras(Compra umaCompra);
    std::vector<std::string> produtos()const;
    std::vector<Produto> prodvendas()const;
    std::vector<Compra> compras()const;
    void setLucro(std::vector<Produto> meusprodutos, std::vector<Compra> minhascompras);
    float getLucro();

};

#endif // EMPRESA_H
