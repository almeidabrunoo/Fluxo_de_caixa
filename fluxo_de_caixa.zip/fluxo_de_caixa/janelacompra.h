#ifndef JANELACOMPRA_H
#define JANELACOMPRA_H

#include <QDialog>
#include "empresa.h"

namespace Ui {
class janelacompra;
}

class janelacompra : public QDialog
{
    Q_OBJECT

public:
    explicit janelacompra(Empresa& emp, QWidget *parent = nullptr);
    ~janelacompra();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::janelacompra *ui;
    Empresa& empcompra;
};

#endif // JANELACOMPRA_H
