#ifndef COMPRA_H
#define COMPRA_H

#include <iostream>
#include <string>
#include "pagamento.h"

class Compra{

private:
    int _qtde;
    float _valor;
    std::string _fornecedor;
    int _dia;
    int _mes;
    int _ano;
    std::string _objeto;
    Pagamento _metodo; //aplicação de associação entre classes
    Pagamento _condicao;

public:
    ~Compra();
    Compra();
    Compra(int qtde, float valor, std::string fornecedor, int dia, int ano, int mes, std::string objeto);
    void setQtde(int qtde);
    void setValor(float valor);
    void setDia(int dia);
    void setMes(int mes);
    void setAno(int ano);
    void setFornecedor(std::string fornecedor);
    void setObjeto(std::string objeto);
    int getQtde();
    float getValor();
    int getDia();
    int getMes();
    int getAno();
    void getData();
    std::string getFornecedor();
    std::string getObjeto();
    void setMetodo(int metodo);
    void setCondicao(int condicao);
    std::string getMetodo();
    std::string getCondicao();


};

#endif
