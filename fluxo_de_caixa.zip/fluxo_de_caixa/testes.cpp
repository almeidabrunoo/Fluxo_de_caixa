#include <iostream>
#include "testes.h"

// testagem das variaveis recebidas, retorna 1 se inválidas 0 se dentro dos conformes
int testevalor(float valor){
    if(valor>0)
        return 0;
    else
        return 1;
}
int testeqtde(int qtde){
    if(qtde>0)
        return 0;
    else
        return 1;
}
int testedata(int dia, int mes, int ano){
    if(dia<1 || dia>31){
        return 1;
    }
    else if(mes<1 || mes>12){
        return 1;
    }
    else if(mes == 2){
        if(dia>29)
            return 1;
    }
    else if(ano<2000 || ano>2100){
        return 1;
    }
    return 0;
}

int testestrings(std::string str){
    if(str.size()< 2)
        return 1;
    else
        return 0;
}

int testemtdcndc(int metodo, int condicao){ //credito = 1 e parcelado =2
    if(metodo>=2){
        if(condicao == 2)
            return 1;
        else
            return 0;
    }
    else
        return 0;
}
