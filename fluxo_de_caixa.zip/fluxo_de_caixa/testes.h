#ifndef TESTES_H
#define TESTES_H
#include <iostream>
#include <string>

// testagem das variaveis recebidas, retorna 1 se inválidas 0 se dentro dos conformes
//Usadas para a parte gráfica
int testevalor(float valor);
int testeqtde(int qtde);
int testedata(int dia, int mes, int ano);
int testestrings(std::string str);
int testemtdcndc(int metodo, int condicao);

#endif // TESTES_H
