#ifndef JANELAVENDA_H
#define JANELAVENDA_H

#include <QDialog>
#include "empresa.h"

namespace Ui {
class janelavenda;
}

class janelavenda : public QDialog
{
    Q_OBJECT

public:
    explicit janelavenda(Empresa& emp,QWidget *parent = nullptr);
    ~janelavenda();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::janelavenda *ui;
    Empresa& empvenda;
};

#endif // JANELAVENDA_H
