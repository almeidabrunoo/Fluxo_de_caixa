#ifndef LUCRO_H
#define LUCRO_H

#include <iostream>
#include <vector>
#include "produto.h"
#include "compra.h"

class Lucro{
private:
    float _meuLucro;
public:
    Lucro();
    Lucro(std::vector<Produto> meusprodutos, std::vector<Compra> minhascompras);
    ~Lucro();
    float operator+= (float outro);//sobrecarga de operador para acessar atributos das classes dentro dos vetores
    float operator-= (float outro);
    void setMeuLucro(std::vector<Produto> meusprodutos, std::vector<Compra> minhascompras);
    float getMeuLucro();
};

#endif
