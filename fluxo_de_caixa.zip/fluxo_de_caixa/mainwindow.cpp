#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
//#include "xlsxdocument.h"


MainWindow::MainWindow(Empresa& emp,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), umaemp{emp}
{
    ui->setupUi(this);
}

MainWindow::~MainWindow(){
    delete ui;
}

//botao adicionar compra
void MainWindow::on_pushButton_2_clicked(){
    hide();
    jcompra = new janelacompra(umaemp, this);
    jcompra->show();

}

//botao adicionar venda
void MainWindow::on_pushButton_clicked(){
    hide();
    jvenda = new janelavenda(umaemp,this);
    jvenda->show();

}

//Botao Visualização de gráficos
void MainWindow::on_pushButton_3_clicked(){
    hide();
    jgraf = new janelagrafico(umaemp,this);
    jgraf->show();
}
