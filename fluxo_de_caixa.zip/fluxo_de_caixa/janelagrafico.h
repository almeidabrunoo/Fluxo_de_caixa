#ifndef JANELAGRAFICO_H
#define JANELAGRAFICO_H

#include <QDialog>
#include "empresa.h"

namespace Ui {
class janelagrafico;
}

class janelagrafico : public QDialog
{
    Q_OBJECT

public:
    explicit janelagrafico(Empresa& emp,QWidget *parent = nullptr);
    ~janelagrafico();

private slots:
    void on_pushButton_clicked();

private:
    Ui::janelagrafico *ui;
    Empresa& empgrafico;
};

#endif // JANELAGRAFICO_H
