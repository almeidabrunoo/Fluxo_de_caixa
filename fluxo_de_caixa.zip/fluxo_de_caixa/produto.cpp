#include <iostream>
#include "string.h"
#include "produto.h"
#include "venda.h"

//constutores
Produto::Produto(int nome, std::string responsavel, int qtde){
    setNome(nome);
    setResponsavel(responsavel);
    setQtde(qtde);

}
Produto::Produto(){

}
//destrutor
Produto::~Produto(){
}
//funçoes setters
void Produto::setResponsavel(std::string responsavel){
    if(responsavel.size() <= 2){ //teste de string para evitar colocar so uma ou duas letras de entrada
        std::string nresponsavel;
        std::cout<< "Responsável inválido. Insira novamente";
        std::getline(std::cin,nresponsavel);
        setResponsavel(nresponsavel);
    }
    else _responsavel = responsavel;

}
void Produto::setNome(std::string nome){
    if(nome.size() <= 2){
        std::string nnome;
        std::cout<< "Responsável inválido. Insira novamente";
        std::getline(std::cin,nnome);
        setResponsavel(nnome);
    }
    else _nome = nome;

}
//para uso sme a parte grafica mantivemos a stter com inteir, tendo entao um polimorfimo simples por sobrecarga de função
void Produto::setNome(int nome){
    switch (nome){
    case 1:
        _nome = "Projeto Eletrico";
        break;
    case 2:
        _nome = "Projeto Fotovoltaico";
        break;
    case 3:
        _nome = "Monitoramento";
        break;
    case 4:
        _nome = "Limpeza e Manutenção";
        break;
    case 5:
        _nome = "Seguro";
        break;
    default:
        std::cout<< "Produto inválido. Insira novamente";
        int nnome;
        std::cin>>nnome;
        setNome(nnome);
        break;
    }

}
//funções getters
std::string Produto::getNome() const {
    return _nome;
}
std::string Produto::getResponsavel() const {
    return _responsavel;
}
