#ifndef PAGAMENTO_H__
#define PAGAMENTO_H__

#include <iostream>
#include <string>

class Pagamento{

private:
    std::string _metodo;
    std::string _condicao;

public:
    ~Pagamento();
    Pagamento();
    Pagamento(int metodo, int condicao);
    void setMetodo(int metodo);
    void setCondicao(int condicao);
    std::string getMetodo();
    std::string getCondicao();
};

#endif
