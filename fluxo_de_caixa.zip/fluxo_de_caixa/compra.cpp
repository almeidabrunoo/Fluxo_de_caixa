#include <iostream>
#include "compra.h"

//contrutor padrao
Compra::Compra(){
}
Compra::Compra(int qtde, float valor, std::string fornecedor, int dia, int mes, int ano, std::string objeto):
    _qtde(qtde), _valor(valor),_fornecedor(fornecedor),  _dia(dia),_mes(mes), _ano(ano), _objeto(objeto)
{

}
//destrutor
Compra::~Compra(){}

//funçoes setters
void Compra::setQtde(int qtde){
    if (qtde <= 0 ){
        std::cout<<"Quantidade inválida. Insira novamente.";
        int nqtde;
        std::cin>>nqtde;
        setQtde(nqtde);
    }
    else _qtde = qtde;
}
void Compra::setValor(float valor){
    if(valor <= 0){
        std::cout<<"Valor inválido. Insira novamente.";
        float nvalor;
        std::cin>>nvalor;
        setValor(nvalor);
    }
    else _valor = valor;
}

void Compra::setDia(int dia){
    if(dia >= 1 && dia < 31){
        _dia = dia;
    }
    else {
        std::cout << "Dia inválido. Insira novamente." <<std::endl;
        int ndia;
        std::cin>>ndia;
        setDia(ndia);
    }
}
void Compra::setAno(int ano){
    if(ano >= 0){
        _ano = ano;
    }
    else {
        std::cout << "Ano inválido. Insira novamente." << std::endl;
        int nano;
        std::cin>>nano;
        setDia(nano);
    }
}
void Compra::setMes(int mes){
    if(mes >= 1 && mes < 13){
        _mes = mes;
    }
    else {
        std::cout << "Mês inválido. Insira novamente." << std::endl;
        int nmes;
        std::cin>>nmes;
        setDia(nmes);
    }

}
void Compra::setFornecedor(std::string fornecedor){
    if(fornecedor.size() <= 1){
       std::string nfornecedor;
       std::cout<< "Fornecedor inválido. Insira novamente";
       std::getline(std::cin,nfornecedor);
       setFornecedor(nfornecedor);
    }
    else _fornecedor = fornecedor;

}
void Compra::setObjeto(std::string objeto){
    if(objeto.size() <= 1){
       std::string nobjeto;
       std::cout<< "Objeto inválido. Insira novamente";
       std::getline(std::cin,nobjeto);
       setObjeto(nobjeto);
    }
    else
    _objeto = objeto;

}
//funçoes getters
int Compra::getQtde(){
    return _qtde;
}
float Compra::getValor(){
    return _valor;
}
int Compra::getDia(){
    return _dia;
}
int Compra::getMes(){
    return _mes;
}
int Compra::getAno(){
    return _ano;
}

void Compra::getData(){
    std::cout << "(" << getDia() << "/" << getMes() << "/" << getAno() << ")" <<std::endl;
}
std::string Compra::getFornecedor(){
    return _fornecedor;
}
std::string Compra::getObjeto(){
    return _objeto;
}
void Compra::setMetodo(int metodo){
    _metodo.setMetodo(metodo);
}
void Compra::setCondicao(int condicao){
    _condicao.setCondicao(condicao);
}
std::string Compra::getMetodo(){
    return _metodo.getMetodo();

}
std::string Compra::getCondicao(){
    return _condicao.getCondicao();

}

