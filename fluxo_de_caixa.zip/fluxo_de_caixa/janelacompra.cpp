#include "janelacompra.h"
#include "ui_janelacompra.h"
#include "compra.h"
#include "testes.h"
#include <QMessageBox>

janelacompra::janelacompra(Empresa& emp, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::janelacompra), empcompra{emp}
{
    ui->setupUi(this);
    //auto compras = empcompra{emp};
}

janelacompra::~janelacompra()
{
    delete ui;
}

//Botao finalizar clicado
void janelacompra::on_pushButton_clicked(){

    Compra c1;
    int tobjeto, tvalor, tqtde, tfornecedor, tdata, tmtdcdc; //variaveis para testagem dos valores

    QString qobjeto = ui->lineEdit->text(); //recebendo primeiro campo em q string
    std::string objeto = qobjeto.toStdString(); // conversao para std string
    //Testar objeto
    if(testestrings(objeto) == 1){
        tobjeto = 1;
        QMessageBox::critical(this,"Nao pode!", "O objeto comprado inserido é inválido!",QMessageBox::Ok);
      }
      else
        tobjeto = 0;

    QString svalor = ui->lineEdit_2->text(); // valor em string
    int valor = svalor.toFloat(); //conversao para float
    if(testevalor(valor) == 1){
        tvalor = 1;
        QMessageBox::critical(this,"Nao pode!", "O valor do produto inserido é inválido!",QMessageBox::Ok);
      }
      else
        tvalor = 0;

    QString sqtde = ui->lineEdit_3->text(); // valor em string
    int qtde = sqtde.toFloat(); //conversao para float
    if(testeqtde(qtde) == 1){
        tqtde = 1;
        QMessageBox::critical(this,"Nao pode!", "A quantidade do produto inserido é inválida!",QMessageBox::Ok);
    }
    else
        tqtde = 0;


    QString sfornecedor = ui->lineEdit_4->text(); //fornecedor em qstring
    std::string fornecedor = sfornecedor.toStdString(); //conversao std string
    if(testestrings(fornecedor) == 1){
        tfornecedor = 1;
        QMessageBox::critical(this,"Nao pode!", "O fornecedor do produto inserido é inválido!",QMessageBox::Ok);
    }
    else
        tfornecedor = 0;

    QString qdia = ui->lineEdit_5->text(); // dia em qstring
    int dia = qdia.toInt(); // conversao em int

    QString qmes = ui->lineEdit_6->text(); //mes em qstring
    int mes = qmes.toInt(); // conversao em int

    QString qano = ui->lineEdit_7->text(); //ano em qstring
    int ano = qano.toInt(); // conversao em int
    if(testedata(dia, mes, ano) == 1){
        tdata = 1;
        QMessageBox::critical(this,"Nao pode!", "A data inserida da compra é inválida!",QMessageBox::Ok);
    }
    else
        tdata = 0;


    QString selecmtd = ui->comboBox->currentText(); //string para comparação do metodo selecionado.
    int nummtd = 0; //numero equivalente na funcao da classe.

    if(selecmtd == "Crédito")
        nummtd = 1;
    else if(selecmtd == "Débito")
        nummtd = 2;
    else if(selecmtd == "Boleto")
        nummtd = 3;
    else if(selecmtd == "Cheque")
        nummtd = 4;
    else if(selecmtd == "Transferência")
        nummtd = 5;

    QString seleccond = ui->comboBox_2->currentText();  //string para comparação da condicao selecionada.
    int numcond;  // numero equivalente na funcao da classe

    if(seleccond == "À vista")
        numcond = 1;
    else
        numcond = 2;

    if(testemtdcndc(nummtd, numcond) == 1){
        tmtdcdc = 1;
        QMessageBox::critical(this,"Nao pode!", "Só é possível parcelar se pagar com crédito!",QMessageBox::Ok);
    }
    else
        tmtdcdc = 0;

    int teste = tobjeto+tvalor+tqtde+tfornecedor+tdata+tmtdcdc;
    if(teste == 0){
        QMessageBox::StandardButton resposta = QMessageBox::question
                (this, "Objeto a ser criado", "Deseja criar o objeto Compra?",QMessageBox::Yes|QMessageBox::No);
        if(resposta == QMessageBox::Yes){
            c1.setObjeto(objeto);
            c1.setValor(valor);
            c1.setQtde(qtde);
            c1.setFornecedor(fornecedor);
            c1.setDia(dia);
            c1.setMes(mes);
            c1.setAno(ano);
            c1.setMetodo(nummtd);
            c1.setCondicao(numcond);
            empcompra.adicionarCompras(c1);// adicionando ao vetor contido em empresa iniciada em main window
            QMessageBox::information(this,"","Objeto Compra criado",QMessageBox::Ok);
        } else
            QMessageBox::information(this,"","Objeto compra não foi criado",QMessageBox::Ok);

    }
    else
        QMessageBox::critical(this,"Erros existentes!", "Conserte os erros antes de poder criar o objeto Compra"
                                                                          ,QMessageBox::Ok);
}
//Botao Voltar clicado
void janelacompra::on_pushButton_2_clicked(){
    hide();
    parentWidget()->show(); //volta para main window

}
