#ifndef PRODUTO_H
#define PRODUTO_H

#include <iostream>
#include <string>
#include "venda.h"

//Produto herdando metodos e atributos de venda
class Produto : public Venda{
private:
    std::string _nome;
    std::string _responsavel;
public:
    ~Produto();
    Produto();
    Produto(int nome, std::string responsavel, int qtde);
    void setNome(int nome);
    void setNome(std::string nome); // polimorfismo para usar na interface grafica onde entradas sao garantidas que sao certas
    std::string getNome() const;
    void setResponsavel(std::string responsavel);
    std::string getResponsavel() const;
};

#endif
