#include <iostream>
#include "pagamento.h"

//construtores
Pagamento::Pagamento(){

}
Pagamento::Pagamento(int metodo, int condicao){
    setMetodo(metodo);
    setCondicao(condicao);

}
//destrutor
Pagamento::~Pagamento(){}

//funçoes setters
void Pagamento::setMetodo(int metodo){

    switch (metodo){ //iniciamos com umeros visando que iriamos usar tabela e que com isto se tornraia mais facil de manejar
    case 1:
        _metodo = "Crédito";
        break;
    case 2:
        _metodo = "Débito";
        break;
    case 3:
        _metodo = "Boleto";
        break;
    case 4:
        _metodo = "Cheque";
        break;
    case 5:
        _metodo = "Transferência";
        break;
    default:
        std::cout<< "Método inválido. Insira novamente";
        int nmetodo;
        std::cin>>nmetodo;
        setMetodo(nmetodo);
        break;
    }

}
void Pagamento::setCondicao(int condicao){ // 1 == à vista 2 == parcelado
    std::string metodo = getMetodo();
    if(metodo == "Crédito"){
        if(condicao == 1) {
            _condicao = "À vista";
        }
        else if(condicao > 2 || condicao < 0){
            std::cout<<std::endl<<"Condição inválida. Insira novamente."<<std::endl;
            int ncondicao;
            std::cin>>ncondicao;
            setCondicao(ncondicao);
        }
        else {
            _condicao = "Parcelado";
            std::cout<<std::endl<<"Em quantas vezes? No máximo 5x sem juros."<<std::endl;
            int vezes;
            std::cin>>vezes;
        }
    }
    else _condicao = "À vista";

}
//funçoes getters
std::string Pagamento::getMetodo(){
    return _metodo;

}
std::string Pagamento::getCondicao(){
    return _condicao;

}

