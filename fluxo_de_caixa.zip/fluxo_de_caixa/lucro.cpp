#include <iostream>
#include "lucro.h"

Lucro::Lucro(){
    _meuLucro = 0;
}

Lucro::Lucro(std::vector<Produto> meusprodutos, std::vector<Compra> minhascompras){
    setMeuLucro(meusprodutos, minhascompras);
}

Lucro::~Lucro(){

}
//sobrecarga para acessar atributos especificos
float Lucro::operator+= (float outro){
    this->_meuLucro = _meuLucro + outro;
    return _meuLucro;
}
float Lucro::operator-= (float outro){
   this->_meuLucro = _meuLucro - outro;
   return _meuLucro; 
}
void Lucro::setMeuLucro(std::vector<Produto> meusprodutos, std::vector<Compra> minhascompras){
    if (meusprodutos.size() == 0 && minhascompras.size() == 0){
        _meuLucro = 0;
        std::cout<<"Listas vazias"<<std::endl;
        return;
    }
    int tam = meusprodutos.size();//evitar warning de comparação de dois tipos diferentes

    for (int i = 0; i < tam; i++){
        this->operator+=(meusprodutos[i].getValor()); //percorre o vetor Dos produtos vendidos somando todos os valores
    }
    //std::cout<<"Sua arrecação foi:"<< _meuLucro <<std::endl;
    for (int i = 0; i<tam; i++){
        this->operator-=(minhascompras[i].getValor()); //percorre o vetor das compras subtraindo do valor antes adiquirido
    }
    //std::cout<<"Obteve um lucro de:"<< _meuLucro<<std::endl;
}
float Lucro::getMeuLucro(){
    return _meuLucro;
}

