#include "mainwindow.h"

#include <QApplication>
#include "empresa.h"

int main(int argc, char *argv[])
{
    Empresa umbrellaCorporation{};

    QApplication a(argc, argv);
    MainWindow w{umbrellaCorporation};
    w.show();
    return a.exec();
}
